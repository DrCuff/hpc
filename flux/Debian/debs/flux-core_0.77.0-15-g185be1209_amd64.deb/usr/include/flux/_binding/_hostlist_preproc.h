struct hostlist *hostlist_create (void);

void hostlist_destroy (struct hostlist *hl);





struct hostlist *hostlist_decode (const char *s);




char *hostlist_encode (struct hostlist *hl);




struct hostlist *hostlist_copy (const struct hostlist *hl);





int hostlist_append (struct hostlist *hl, const char *hosts);







int hostlist_append_list (struct hostlist *hl1, struct hostlist *hl2);





const char * hostlist_nth (struct hostlist * hl, int n);
int hostlist_find (struct hostlist * hl, const char *hostname);
struct hostlist_hostname *hostlist_hostname_create (const char *hostname);




void hostlist_hostname_destroy (struct hostlist_hostname *hn);
int hostlist_find_hostname (struct hostlist *hl, struct hostlist_hostname *hn);






int hostlist_delete (struct hostlist * hl, const char *hosts);




int hostlist_count (struct hostlist * hl);







void hostlist_sort (struct hostlist * hl);




void hostlist_uniq (struct hostlist *hl);
const char * hostlist_first (struct hostlist *hl);
const char * hostlist_last (struct hostlist *hl);
const char * hostlist_next (struct hostlist *hl);
const char * hostlist_current (struct hostlist *hl);





int hostlist_remove_current (struct hostlist *hl);
